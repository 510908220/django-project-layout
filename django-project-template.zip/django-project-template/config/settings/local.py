# -*- coding: utf-8 -*-

from .base import *

DEBUG = True

INSTALLED_APPS += ('debug_toolbar',)
